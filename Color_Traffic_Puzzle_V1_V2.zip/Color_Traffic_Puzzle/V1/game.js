
const VERSION="V1";
const PERSIST=false;
const LEVELS=[{"cars": [{"id": 0, "color": "red", "dir": "right", "x": 11, "y": 6}, {"id": 1, "color": "red", "dir": "right", "x": 33, "y": 7}, {"id": 2, "color": "red", "dir": "down", "x": 57, "y": 9}, {"id": 3, "color": "green", "dir": "up", "x": 78, "y": 5}, {"id": 4, "color": "blue", "dir": "right", "x": 10, "y": 30}], "passengers": ["blue", "red", "red", "red", "red", "red", "green", "blue", "green", "red", "red"]}, {"cars": [{"id": 0, "color": "red", "dir": "left", "x": 8, "y": 9}, {"id": 1, "color": "red", "dir": "down", "x": 29, "y": 11}, {"id": 2, "color": "green", "dir": "down", "x": 55, "y": 8}, {"id": 3, "color": "red", "dir": "up", "x": 78, "y": 5}, {"id": 4, "color": "red", "dir": "down", "x": 7, "y": 28}], "passengers": ["red", "red", "green", "red", "red", "green", "red", "red", "red", "green", "red", "red"]}, {"cars": [{"id": 0, "color": "red", "dir": "up", "x": 9, "y": 7}, {"id": 1, "color": "red", "dir": "left", "x": 28, "y": 9}, {"id": 2, "color": "red", "dir": "right", "x": 55, "y": 7}, {"id": 3, "color": "blue", "dir": "right", "x": 74, "y": 11}, {"id": 4, "color": "red", "dir": "left", "x": 7, "y": 31}, {"id": 5, "color": "green", "dir": "left", "x": 31, "y": 28}], "passengers": ["red", "green", "red", "red", "blue", "blue", "red", "green", "red", "red", "red", "red", "red"]}, {"cars": [{"id": 0, "color": "red", "dir": "right", "x": 11, "y": 5}, {"id": 1, "color": "green", "dir": "left", "x": 28, "y": 6}, {"id": 2, "color": "blue", "dir": "up", "x": 57, "y": 9}, {"id": 3, "color": "blue", "dir": "up", "x": 79, "y": 11}, {"id": 4, "color": "green", "dir": "down", "x": 5, "y": 28}, {"id": 5, "color": "green", "dir": "right", "x": 29, "y": 30}], "passengers": ["blue", "red", "red", "blue", "green", "blue", "blue", "green", "green", "blue", "blue", "green", "green", "green", "green", "red"]}, {"cars": [{"id": 0, "color": "green", "dir": "down", "x": 9, "y": 6}, {"id": 1, "color": "green", "dir": "left", "x": 32, "y": 6}, {"id": 2, "color": "green", "dir": "right", "x": 51, "y": 7}, {"id": 3, "color": "blue", "dir": "up", "x": 79, "y": 11}, {"id": 4, "color": "blue", "dir": "right", "x": 5, "y": 29}, {"id": 5, "color": "red", "dir": "left", "x": 30, "y": 29}], "passengers": ["red", "green", "blue", "red", "green", "blue", "green", "blue", "green", "green", "green", "green", "red", "blue"]}, {"cars": [{"id": 0, "color": "red", "dir": "right", "x": 6, "y": 8}, {"id": 1, "color": "blue", "dir": "up", "x": 34, "y": 5}, {"id": 2, "color": "green", "dir": "up", "x": 54, "y": 10}, {"id": 3, "color": "blue", "dir": "down", "x": 77, "y": 5}, {"id": 4, "color": "red", "dir": "left", "x": 5, "y": 25}, {"id": 5, "color": "green", "dir": "down", "x": 28, "y": 29}, {"id": 6, "color": "green", "dir": "up", "x": 53, "y": 26}], "passengers": ["red", "blue", "green", "red", "green", "blue", "green", "green", "blue", "red", "blue", "green", "blue", "red", "green", "red", "red", "green"]}, {"cars": [{"id": 0, "color": "green", "dir": "up", "x": 5, "y": 10}, {"id": 1, "color": "green", "dir": "up", "x": 30, "y": 11}, {"id": 2, "color": "green", "dir": "right", "x": 52, "y": 11}, {"id": 3, "color": "blue", "dir": "up", "x": 78, "y": 9}, {"id": 4, "color": "green", "dir": "left", "x": 8, "y": 29}, {"id": 5, "color": "red", "dir": "right", "x": 34, "y": 30}, {"id": 6, "color": "red", "dir": "down", "x": 51, "y": 26}], "passengers": ["green", "red", "green", "green", "red", "green", "green", "green", "green", "green", "red", "red", "blue", "green", "green", "green", "blue", "red"]}, {"cars": [{"id": 0, "color": "green", "dir": "right", "x": 10, "y": 10}, {"id": 1, "color": "blue", "dir": "down", "x": 31, "y": 8}, {"id": 2, "color": "red", "dir": "right", "x": 56, "y": 10}, {"id": 3, "color": "red", "dir": "up", "x": 77, "y": 10}, {"id": 4, "color": "red", "dir": "right", "x": 11, "y": 29}, {"id": 5, "color": "green", "dir": "right", "x": 31, "y": 28}, {"id": 6, "color": "red", "dir": "left", "x": 55, "y": 28}], "passengers": ["green", "red", "red", "green", "red", "green", "red", "red", "red", "green", "red", "blue", "green", "blue", "red", "red", "red"]}, {"cars": [{"id": 0, "color": "red", "dir": "left", "x": 7, "y": 9}, {"id": 1, "color": "red", "dir": "down", "x": 34, "y": 8}, {"id": 2, "color": "red", "dir": "left", "x": 51, "y": 11}, {"id": 3, "color": "red", "dir": "right", "x": 76, "y": 5}, {"id": 4, "color": "blue", "dir": "down", "x": 5, "y": 29}, {"id": 5, "color": "red", "dir": "right", "x": 31, "y": 30}, {"id": 6, "color": "red", "dir": "right", "x": 52, "y": 28}, {"id": 7, "color": "red", "dir": "down", "x": 78, "y": 28}], "passengers": ["red", "blue", "red", "red", "red", "red", "red", "red", "red", "red", "blue", "red", "blue", "red", "red", "red", "red", "red", "red"]}, {"cars": [{"id": 0, "color": "blue", "dir": "down", "x": 5, "y": 11}, {"id": 1, "color": "yellow", "dir": "up", "x": 31, "y": 7}, {"id": 2, "color": "yellow", "dir": "down", "x": 51, "y": 9}, {"id": 3, "color": "yellow", "dir": "down", "x": 79, "y": 11}, {"id": 4, "color": "yellow", "dir": "left", "x": 8, "y": 30}, {"id": 5, "color": "yellow", "dir": "left", "x": 31, "y": 31}, {"id": 6, "color": "yellow", "dir": "up", "x": 56, "y": 27}, {"id": 7, "color": "red", "dir": "down", "x": 74, "y": 26}], "passengers": ["yellow", "blue", "yellow", "yellow", "yellow", "red", "yellow", "yellow", "yellow", "yellow", "red", "yellow", "yellow", "red", "yellow", "blue", "yellow", "yellow", "yellow"]}, {"cars": [{"id": 0, "color": "green", "dir": "down", "x": 11, "y": 7}, {"id": 1, "color": "yellow", "dir": "up", "x": 32, "y": 6}, {"id": 2, "color": "blue", "dir": "left", "x": 52, "y": 6}, {"id": 3, "color": "red", "dir": "left", "x": 79, "y": 9}, {"id": 4, "color": "yellow", "dir": "left", "x": 8, "y": 25}, {"id": 5, "color": "yellow", "dir": "right", "x": 28, "y": 29}, {"id": 6, "color": "green", "dir": "left", "x": 52, "y": 29}, {"id": 7, "color": "blue", "dir": "right", "x": 75, "y": 30}], "passengers": ["red", "yellow", "yellow", "green", "green", "blue", "yellow", "red", "blue", "yellow", "green", "yellow", "green", "blue", "yellow", "yellow", "green", "blue", "yellow", "yellow"]}, {"cars": [{"id": 0, "color": "yellow", "dir": "right", "x": 7, "y": 5}, {"id": 1, "color": "yellow", "dir": "right", "x": 28, "y": 11}, {"id": 2, "color": "blue", "dir": "right", "x": 53, "y": 7}, {"id": 3, "color": "red", "dir": "down", "x": 78, "y": 7}, {"id": 4, "color": "blue", "dir": "left", "x": 8, "y": 29}, {"id": 5, "color": "green", "dir": "up", "x": 29, "y": 26}, {"id": 6, "color": "blue", "dir": "down", "x": 51, "y": 26}, {"id": 7, "color": "green", "dir": "up", "x": 75, "y": 25}, {"id": 8, "color": "yellow", "dir": "right", "x": 9, "y": 45}], "passengers": ["blue", "yellow", "yellow", "blue", "blue", "blue", "blue", "green", "blue", "red", "yellow", "yellow", "green", "green", "yellow", "red", "yellow", "blue", "yellow", "green", "green", "red"]}, {"cars": [{"id": 0, "color": "red", "dir": "down", "x": 5, "y": 7}, {"id": 1, "color": "yellow", "dir": "left", "x": 33, "y": 8}, {"id": 2, "color": "green", "dir": "down", "x": 54, "y": 8}, {"id": 3, "color": "yellow", "dir": "right", "x": 76, "y": 11}, {"id": 4, "color": "green", "dir": "down", "x": 9, "y": 30}, {"id": 5, "color": "green", "dir": "up", "x": 32, "y": 25}, {"id": 6, "color": "green", "dir": "up", "x": 55, "y": 26}, {"id": 7, "color": "red", "dir": "up", "x": 74, "y": 31}, {"id": 8, "color": "blue", "dir": "left", "x": 5, "y": 48}], "passengers": ["yellow", "yellow", "green", "green", "green", "green", "red", "blue", "green", "yellow", "green", "green", "green", "green", "yellow", "yellow", "green", "red", "blue", "red", "blue", "red", "red", "green"]}, {"cars": [{"id": 0, "color": "yellow", "dir": "up", "x": 9, "y": 11}, {"id": 1, "color": "red", "dir": "left", "x": 28, "y": 10}, {"id": 2, "color": "blue", "dir": "right", "x": 53, "y": 6}, {"id": 3, "color": "green", "dir": "left", "x": 78, "y": 7}, {"id": 4, "color": "yellow", "dir": "left", "x": 8, "y": 28}, {"id": 5, "color": "yellow", "dir": "right", "x": 31, "y": 29}, {"id": 6, "color": "yellow", "dir": "down", "x": 51, "y": 25}, {"id": 7, "color": "yellow", "dir": "right", "x": 76, "y": 27}, {"id": 8, "color": "red", "dir": "left", "x": 11, "y": 46}], "passengers": ["yellow", "yellow", "yellow", "red", "red", "yellow", "green", "yellow", "red", "blue", "blue", "green", "green", "red", "yellow", "yellow", "yellow", "yellow", "yellow", "yellow", "yellow", "yellow"]}, {"cars": [{"id": 0, "color": "green", "dir": "left", "x": 9, "y": 10}, {"id": 1, "color": "red", "dir": "left", "x": 32, "y": 11}, {"id": 2, "color": "yellow", "dir": "down", "x": 54, "y": 6}, {"id": 3, "color": "blue", "dir": "right", "x": 74, "y": 6}, {"id": 4, "color": "red", "dir": "down", "x": 6, "y": 29}, {"id": 5, "color": "blue", "dir": "right", "x": 31, "y": 26}, {"id": 6, "color": "blue", "dir": "left", "x": 52, "y": 25}, {"id": 7, "color": "blue", "dir": "up", "x": 79, "y": 31}, {"id": 8, "color": "yellow", "dir": "up", "x": 8, "y": 46}, {"id": 9, "color": "red", "dir": "up", "x": 33, "y": 49}], "passengers": ["green", "red", "red", "blue", "green", "red", "red", "blue", "blue", "red", "yellow", "yellow", "yellow", "blue", "blue", "red", "blue", "red", "red", "blue", "green", "blue", "blue", "red", "blue", "yellow"]}, {"cars": [{"id": 0, "color": "blue", "dir": "left", "x": 8, "y": 11}, {"id": 1, "color": "green", "dir": "up", "x": 32, "y": 7}, {"id": 2, "color": "green", "dir": "up", "x": 51, "y": 9}, {"id": 3, "color": "green", "dir": "down", "x": 79, "y": 5}, {"id": 4, "color": "red", "dir": "left", "x": 8, "y": 26}, {"id": 5, "color": "red", "dir": "down", "x": 34, "y": 26}, {"id": 6, "color": "blue", "dir": "down", "x": 52, "y": 30}, {"id": 7, "color": "red", "dir": "left", "x": 79, "y": 31}, {"id": 8, "color": "blue", "dir": "left", "x": 11, "y": 46}, {"id": 9, "color": "green", "dir": "down", "x": 32, "y": 50}], "passengers": ["green", "green", "blue", "red", "blue", "red", "red", "green", "blue", "red", "red", "green", "green", "blue", "blue", "green", "green", "blue", "red", "red", "green", "green", "blue", "green"]}, {"cars": [{"id": 0, "color": "blue", "dir": "up", "x": 5, "y": 7}, {"id": 1, "color": "yellow", "dir": "right", "x": 28, "y": 9}, {"id": 2, "color": "yellow", "dir": "up", "x": 51, "y": 6}, {"id": 3, "color": "green", "dir": "up", "x": 76, "y": 9}, {"id": 4, "color": "yellow", "dir": "up", "x": 9, "y": 26}, {"id": 5, "color": "green", "dir": "right", "x": 28, "y": 30}, {"id": 6, "color": "blue", "dir": "up", "x": 54, "y": 29}, {"id": 7, "color": "yellow", "dir": "left", "x": 76, "y": 31}, {"id": 8, "color": "red", "dir": "down", "x": 6, "y": 46}, {"id": 9, "color": "blue", "dir": "down", "x": 30, "y": 48}], "passengers": ["yellow", "yellow", "blue", "green", "blue", "yellow", "yellow", "red", "green", "green", "yellow", "blue", "yellow", "blue", "blue", "blue", "yellow", "blue", "yellow", "red", "green", "blue", "green", "yellow"]}, {"cars": [{"id": 0, "color": "yellow", "dir": "up", "x": 9, "y": 5}, {"id": 1, "color": "blue", "dir": "down", "x": 28, "y": 7}, {"id": 2, "color": "red", "dir": "right", "x": 51, "y": 7}, {"id": 3, "color": "yellow", "dir": "right", "x": 78, "y": 6}, {"id": 4, "color": "yellow", "dir": "up", "x": 7, "y": 27}, {"id": 5, "color": "green", "dir": "right", "x": 28, "y": 26}, {"id": 6, "color": "red", "dir": "left", "x": 52, "y": 31}, {"id": 7, "color": "green", "dir": "up", "x": 76, "y": 29}, {"id": 8, "color": "green", "dir": "left", "x": 11, "y": 51}, {"id": 9, "color": "red", "dir": "up", "x": 33, "y": 48}, {"id": 10, "color": "red", "dir": "down", "x": 51, "y": 47}], "passengers": ["red", "red", "yellow", "green", "yellow", "blue", "red", "red", "green", "yellow", "yellow", "green", "yellow", "green", "red", "yellow", "blue", "green", "green", "green", "red", "red", "blue", "yellow", "red", "yellow", "yellow"]}, {"cars": [{"id": 0, "color": "red", "dir": "right", "x": 10, "y": 6}, {"id": 1, "color": "blue", "dir": "left", "x": 28, "y": 7}, {"id": 2, "color": "blue", "dir": "left", "x": 51, "y": 6}, {"id": 3, "color": "green", "dir": "right", "x": 76, "y": 5}, {"id": 4, "color": "green", "dir": "up", "x": 11, "y": 25}, {"id": 5, "color": "green", "dir": "up", "x": 30, "y": 26}, {"id": 6, "color": "yellow", "dir": "right", "x": 51, "y": 31}, {"id": 7, "color": "green", "dir": "down", "x": 79, "y": 26}, {"id": 8, "color": "yellow", "dir": "up", "x": 11, "y": 48}, {"id": 9, "color": "blue", "dir": "right", "x": 29, "y": 49}, {"id": 10, "color": "yellow", "dir": "right", "x": 55, "y": 45}], "passengers": ["blue", "red", "green", "yellow", "blue", "yellow", "blue", "blue", "blue", "green", "green", "green", "green", "yellow", "red", "green", "blue", "yellow", "blue", "green", "blue", "green", "red", "yellow", "green", "yellow", "green", "yellow"]}, {"cars": [{"id": 0, "color": "blue", "dir": "up", "x": 11, "y": 5}, {"id": 1, "color": "red", "dir": "left", "x": 32, "y": 11}, {"id": 2, "color": "blue", "dir": "down", "x": 56, "y": 8}, {"id": 3, "color": "purple", "dir": "up", "x": 74, "y": 6}, {"id": 4, "color": "yellow", "dir": "left", "x": 6, "y": 26}, {"id": 5, "color": "green", "dir": "up", "x": 31, "y": 29}, {"id": 6, "color": "red", "dir": "left", "x": 57, "y": 25}, {"id": 7, "color": "green", "dir": "right", "x": 79, "y": 31}, {"id": 8, "color": "red", "dir": "up", "x": 9, "y": 50}, {"id": 9, "color": "red", "dir": "down", "x": 31, "y": 47}, {"id": 10, "color": "purple", "dir": "down", "x": 54, "y": 51}], "passengers": ["purple", "purple", "purple", "green", "red", "yellow", "red", "blue", "purple", "yellow", "red", "red", "blue", "green", "blue", "green", "red", "red", "red", "blue", "red", "green", "blue", "red", "blue", "green"]}];
const COLOR={"red": "#ef3340", "blue": "#1677ff", "green": "#20c05c", "yellow": "#f4c20d", "purple": "#8b4de8", "pink": "#ed3fb6", "orange": "#f28b24", "cyan": "#19c7d8"};
let levelIndex=0, state=null, history=[], coins=0, unlocked=1;

const $=s=>document.querySelector(s);
const road=$("#road"), queueEl=$("#queue"), msg=$("#message");
function loadSave(){
  if(!PERSIST) return;
  try{
    const s=JSON.parse(localStorage.getItem("ctp-save")||"{}");
    levelIndex=Math.max(0,Math.min((s.level||1)-1,LEVELS.length-1));
    unlocked=Math.max(1,Math.min(s.unlocked||1,LEVELS.length));
    coins=s.coins||0;
  }catch(e){}
}
function save(){
 if(PERSIST)localStorage.setItem("ctp-save",JSON.stringify({level:levelIndex+1,unlocked,coins}));
}
function clone(o){return JSON.parse(JSON.stringify(o));}
function startLevel(i){
 levelIndex=i; state=clone(LEVELS[i]); state.removed=[]; history=[];
 $("#levelNo").textContent=i+1; $("#coins").textContent=coins;
 hideOverlay(); render(); save();
}
function render(){
 queueEl.innerHTML="";
 state.passengers.forEach(c=>{
   const p=document.createElement("div"); p.className="person"; p.style.background=COLOR[c]; p.title=c; queueEl.appendChild(p);
 });
 road.innerHTML="";
 state.cars.filter(c=>!state.removed.includes(c.id)).forEach(c=>{
   const el=document.createElement("div"); el.className="car"; el.dataset.id=c.id;
   el.style.left=c.x+"%"; el.style.top=c.y+"%"; el.style.background=COLOR[c.color];
   el.innerHTML=`<span class="arrow">${arrow(c.dir)}</span>`;
   el.onclick=()=>moveCar(c.id,el); road.appendChild(el);
 });
 $("#leftCars").textContent=state.cars.length-state.removed.length;
 $("#undoBtn").disabled=history.length===0;
}
function arrow(d){return d==="up"?"↑":d==="down"?"↓":d==="left"?"←":"→"}
function rect(c){
 const w=9,h=8; return {l:c.x,r:c.x+w,t:c.y,b:c.y+h};
}
function blocks(a,b){
 const A=rect(a), B=rect(b), gap=3;
 if(a.dir==="right") return B.l>A.l && B.l<A.r+35 && !(B.b<A.t-gap||B.t>A.b+gap);
 if(a.dir==="left") return B.r<A.r && B.r>A.l-35 && !(B.b<A.t-gap||B.t>A.b+gap);
 if(a.dir==="down") return B.t>A.t && B.t<A.b+35 && !(B.r<A.l-gap||B.l>A.r+gap);
 return B.b<A.b && B.b>A.t-35 && !(B.r<A.l-gap||B.l>A.r+gap);
}
function canExit(car){
 return !state.cars.some(o=>o.id!==car.id&&!state.removed.includes(o.id)&&blocks(car,o));
}
function moveCar(id,el){
 const car=state.cars.find(c=>c.id===id);
 if(!canExit(car)){
   el.classList.add("blocked"); setTimeout(()=>el.classList.remove("blocked"),350);
   msg.textContent="Dieses Auto ist blockiert.";
   return;
 }
 history.push(clone(state));
 state.removed.push(id);
 let boarded=0;
 for(let i=state.passengers.length-1;i>=0 && boarded<3;i--){
   if(state.passengers[i]===car.color){state.passengers.splice(i,1);boarded++;}
 }
 let dx=0,dy=0;
 if(car.dir==="left")dx="-900px"; if(car.dir==="right")dx="900px";
 if(car.dir==="up")dy="-900px"; if(car.dir==="down")dy="900px";
 el.style.setProperty("--dx",dx); el.style.setProperty("--dy",dy); el.classList.add("exit");
 msg.textContent=boarded?`${boarded} passende Fahrgäste sind eingestiegen.`:"Kein passender Fahrgast – das Auto fährt leer.";
 setTimeout(()=>{render();checkWin();},220);
}
function checkWin(){
 if(state.cars.length===state.removed.length){
   if(state.passengers.length===0){
     coins+=10; unlocked=Math.max(unlocked,Math.min(levelIndex+2,LEVELS.length)); save();
     showOverlay("Level geschafft!","Du erhältst 10 Sterne.",false);
   }else{
     showOverlay("Noch nicht gelöst",`${state.passengers.length} Fahrgäste warten noch. Starte neu oder gehe zurück.`,false);
   }
 }
}
function undo(){
 if(!history.length)return; state=history.pop(); msg.textContent="Letzten Zug rückgängig gemacht."; render();
}
function hint(){
 const possible=state.cars.filter(c=>!state.removed.includes(c.id)&&canExit(c));
 const best=possible.find(c=>state.passengers.includes(c.color))||possible[0];
 if(!best){msg.textContent="Kein freies Auto. Nutze Rückgängig oder Neustart.";return;}
 const el=[...document.querySelectorAll(".car")].find(x=>+x.dataset.id===best.id);
 el.animate([{transform:"scale(1)"},{transform:"scale(1.2)"},{transform:"scale(1)"}],{duration:700,iterations:2});
 msg.textContent="Dieses Auto ist aktuell frei.";
}
function showOverlay(t,tx,grid){
 $("#overlayTitle").textContent=t; $("#overlayText").textContent=tx;
 $("#levelGrid").style.display=grid?"grid":"none";
 $("#nextBtn").style.display=grid?"none":"inline-block";
 $("#overlay").classList.add("show");
}
function hideOverlay(){$("#overlay").classList.remove("show")}
function openLevels(){
 const g=$("#levelGrid"); g.innerHTML="";
 for(let i=0;i<LEVELS.length;i++){
   const b=document.createElement("button"); b.className="level-btn"+(i+1>unlocked?" locked":"");
   b.textContent=i+1; b.disabled=i+1>unlocked; b.onclick=()=>startLevel(i); g.appendChild(b);
 }
 showOverlay("Level auswählen",PERSIST?"Dein Fortschritt wird automatisch gespeichert.":"V1 enthält 20 Testlevel.",true);
}
$("#undoBtn").onclick=undo;
$("#hintBtn").onclick=hint;
$("#restartBtn").onclick=()=>startLevel(levelIndex);
$("#levelsBtn").onclick=openLevels;
$("#closeBtn").onclick=hideOverlay;
$("#nextBtn").onclick=()=>{ if(levelIndex<LEVELS.length-1)startLevel(levelIndex+1); else hideOverlay(); };
loadSave(); startLevel(levelIndex);
