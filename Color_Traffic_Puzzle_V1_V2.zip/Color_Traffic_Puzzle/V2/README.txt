COLOR TRAFFIC PUZZLE V2

Start:
1. Ordner öffnen.
2. index.html im Browser öffnen.
3. Auf iPhone/iPad: in Safari öffnen und „Zum Home-Bildschirm“ wählen.

Spiel:
- Tippe ein Auto an.
- Es kann nur in Pfeilrichtung ausfahren.
- Blockierte Autos müssen zuerst freigeräumt werden.
- Bis zu drei farblich passende Fahrgäste steigen ein.
- Ziel: alle Autos und alle Fahrgäste entfernen.

V2:
100 Level, automatische Speicherung, Sterne, Level-Freischaltung, Rückgängig, Hinweise.

Hinweis:
Dies ist eine eigenständig entwickelte HTML5-Prototyp-Version mit eigener Grafik und eigenem Code.
